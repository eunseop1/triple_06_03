package kr.human.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class MyListener1
 *
 */
// 수동으로 등록해보려면 web.xml에 등록해야 한다
public class MyListener2 implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public MyListener2() {
        System.out.println("MyListener2 생성자 호출");
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	System.out.println("MyListener2 contextDestroyed() 호출: 앱어플리케이션이 종료되었다");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    	System.out.println("MyListener2 contextInitialized() 호출: 앱어플리케이션이 시작되었다");
    	
    	ServletContext context = sce.getServletContext();//어플리케이션 객체 얻기
    	String visit = context.getInitParameter("visit");
    	System.out.println("전체 누적 접속자수: " + visit);
    	context.setAttribute("visit", visit);// 어플리케이션 영역에 저장
    }
	
}
