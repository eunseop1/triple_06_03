package kr.human.listener;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class AppChangeListener
 *
 */
@WebListener
public class AppChangeListener implements ServletContextAttributeListener {

    /**
     * Default constructor. 
     */
    public AppChangeListener() {
        // TODO Auto-generated constructor stub생성자
    }

	/**
     * @see ServletContextAttributeListener#attributeAdded(ServletContextAttributeEvent)
     */
    public void attributeAdded(ServletContextAttributeEvent scae)  { 
         // TODO Auto-generated method stub속성에 값이 추가될때
    	System.out.println("변수가 등록되었다");
    }

	/**
     * @see ServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
     */
    public void attributeRemoved(ServletContextAttributeEvent scae)  { 
         // TODO Auto-generated method stub속성에 값이 제거될때
    	System.out.println("변수가 삭제되었다");
    }

	/**
     * @see ServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
     */
    public void attributeReplaced(ServletContextAttributeEvent scae)  { 
         // TODO Auto-generated method stub속성에 값이 변경될때
    	System.out.println("변수가 변경되었다");
    }
	
}
