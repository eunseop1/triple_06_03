package kr.human.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class MyFilter
 */
@WebFilter({"/board/*","/admin/*"})
//모든 요청에 필터가 작동하라는 의미
//괄호안은 매핑을 의미
//매핑을 배열형식으로 지정해서 원하는 폴더 안에서만 작동되게 할수도 있다
public class MyFilter2 implements Filter {

    /**
     * Default constructor. 
     */
    public MyFilter2() {
        System.out.println("MyFilter2 생성자가 호출!!!");
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("destroy2 호출!!!");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		// 요청을 변경할때 이 부분에서 처리한다
		System.out.println("doFilter2 호출!!! 전처리1");
		
		// 이 부분을 꼭 써야 다음 필터로 연결된다
		chain.doFilter(request, response);
		
		//응답을 변경할때 이 부분에서 처리한다
		System.out.println("doFilter2 호출!!! 후처리1");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("init2 호출!!!");
	}

}
