package kr.human.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class MyFilter
 */
// @WebFilter("/MyFilter")
public class MyFilter implements Filter {

    /**
     * Default constructor. 
     */
    public MyFilter() {
        System.out.println("MyFilter 생성자 호출!!!!");
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("MyFilter destroy() 호출!!!!");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// 요청을 변경할때 이부분에서 처리한다.
		System.out.println("MyFilter doFilter() 호출!!!!  전처리1");

		//이 부분을 꼭 써야 다음 필터로 연결이된다.
		chain.doFilter(request, response);
		
		// 응답을 변경할때  이부분에서 처리한다.
		System.out.println("MyFilter doFilter() 호출!!!!  후처리1");
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("MyFilter init() 호출!!!!");
	}

}
